import React, { useState, useEffect } from "react";
import styles from "./HiringStats.module.css";

/* must match ALL_CANDIDATES in 07_CandidatesApplied.jsx exactly */
const ALL_CANDIDATES = [
  { id: 1, name: "Rahul Sharma", role: "Frontend Dev",    score: 87, resume: "/resumes/resume2.pdf" },
  { id: 2, name: "Priya Singh",  role: "UI/UX Designer",  score: 92, resume: "/resumes/resume1.pdf" },
  { id: 3, name: "Arjun Mehta",  role: "Backend Dev",     score: 78, resume: "/resumes/resume3.pdf" },
  { id: 4, name: "Sneha Reddy",  role: "Data Analyst",    score: 84, resume: "/resumes/resume4.pdf" },
  { id: 5, name: "Karan Verma",  role: "DevOps Engineer", score: 76, resume: "/resumes/resume5.pdf" },
];

function loadDecisions(jobs) {
  const accepted = [], rejected = [];
  jobs.forEach(job => {
    try {
      const d = JSON.parse(localStorage.getItem(`hireon_decisions_${job.id}`)) || {};
      ALL_CANDIDATES.forEach(c => {
        const entry = { ...c, company: job.company, jobRole: job.role, jobId: job.id };
        if (d[String(c.id)] === "Accepted") accepted.push(entry);
        if (d[String(c.id)] === "Rejected") rejected.push(entry);
      });
    } catch {}
  });
  return { accepted, rejected };
}

/* ── FULL-WIDTH FUNNEL ── */
function Funnel({ total, accepted, rejected, pending }) {
  const stages = [
    { label: "Applied",     value: total,              color: "#4f8ef7" },
    { label: "Reviewed",    value: accepted + rejected, color: "#a78bfa" },
    { label: "Shortlisted", value: accepted + pending,  color: "#fbbf24" },
    { label: "Accepted",    value: accepted,            color: "#00d4aa" },
  ];
  const max = stages[0].value || 1;

  return (
    <div className={styles.funnelWrap}>
      {stages.map((s, i) => {
        const pct  = Math.round((s.value / max) * 100);
        const drop = i < stages.length - 1
          ? Math.round(((stages[i].value - stages[i + 1].value) / max) * 100)
          : null;
        return (
          <React.Fragment key={s.label}>
            <div className={styles.funnelRow}>
              <div className={styles.funnelMeta}>
                <span className={styles.funnelLabel}>{s.label}</span>
                <span className={styles.funnelCount} style={{ color: s.color }}>{s.value} candidates</span>
              </div>
              <div className={styles.funnelTrack}>
                <div
                  className={styles.funnelFill}
                  style={{ width: `${pct}%`, background: s.color }}
                />
                <span className={styles.funnelPct}>{pct}%</span>
              </div>
            </div>
            {drop !== null && (
              <div className={styles.funnelConnector}>
                <div className={styles.connectorLine} />
                <span className={styles.connectorDrop}>↓ {drop}% drop-off</span>
                <div className={styles.connectorLine} />
              </div>
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
}

/* ── CANDIDATE TABLE ── */
function CandidateTable({ candidates, type }) {
  const isAccepted = type === "Accepted";
  const accentColor = isAccepted ? "#00d4aa" : "#f87171";
  const accentBg    = isAccepted ? "rgba(0,212,170,0.06)"   : "rgba(248,113,113,0.06)";
  const accentBdr   = isAccepted ? "rgba(0,212,170,0.14)"   : "rgba(248,113,113,0.14)";

  if (candidates.length === 0) {
    return (
      <div className={styles.tableEmpty}>
        No {type.toLowerCase()} candidates yet — decisions made in <strong>View Applicants</strong> will appear here.
      </div>
    );
  }

  const initials = (name) => name.split(" ").map(n => n[0]).join("").toUpperCase();

  return (
    <div className={styles.tableWrap} style={{ borderColor: accentBdr }}>
      <table className={styles.table}>
        <thead>
          <tr>
            {["#", "Candidate", "Applied For", "Company", "ATS Score", "Resume"].map(h => (
              <th key={h} className={styles.th}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {candidates.map((c, i) => (
            <tr key={`${c.id}-${c.jobId}`} className={styles.tr}>
              <td className={styles.td} style={{ color: "#334155", width: 32 }}>{i + 1}</td>
              <td className={styles.td}>
                <div className={styles.nameCell}>
                  <div className={styles.tableAvatar} style={{ background: accentBg, borderColor: accentBdr, color: accentColor }}>
                    {initials(c.name)}
                  </div>
                  <span className={styles.candidateName}>{c.name}</span>
                </div>
              </td>
              <td className={styles.td} style={{ color: "#64748b" }}>{c.role}</td>
              <td className={styles.td} style={{ color: "#64748b" }}>{c.company}</td>
              <td className={styles.td}>
                <div className={styles.scoreCell}>
                  <div className={styles.scoreMiniTrack}>
                    <div
                      className={styles.scoreMiniBar}
                      style={{ width: `${c.score}%`, background: accentColor }}
                    />
                  </div>
                  <span style={{ color: accentColor, fontSize: 12, fontWeight: 700 }}>{c.score}%</span>
                </div>
              </td>
              <td className={styles.td}>
                <a
                  href={c.resume}
                  target="_blank"
                  rel="noreferrer"
                  className={styles.resumeLink}
                  style={{ color: accentColor, borderColor: accentBdr }}
                >
                  View →
                </a>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ── MAIN MODAL ── */
export const HiringStats = ({ jobs, onClose }) => {
  const [activeTable, setActiveTable] = useState(null);
  const [decided, setDecided]         = useState({ accepted: [], rejected: [] });

  useEffect(() => {
    setDecided(loadDecisions(jobs));
  }, [jobs]);

  const totalApplicants = jobs.reduce((a, j) => a + j.applicants, 0);
  const totalAccepted   = decided.accepted.length;
  const totalRejected   = decided.rejected.length;
  const totalPending    = Math.max(0, totalApplicants - totalAccepted - totalRejected);
  const acceptRate      = totalApplicants > 0 ? Math.round((totalAccepted / totalApplicants) * 100) : 0;

  const overviewItems = [
    { label: "Total Applicants", val: totalApplicants, color: "#4f8ef7",  bg: "rgba(79,142,247,0.08)",  bdr: "rgba(79,142,247,0.18)"  },
    { label: "Accepted",         val: totalAccepted,   color: "#00d4aa",  bg: "rgba(0,212,170,0.08)",   bdr: "rgba(0,212,170,0.18)"   },
    { label: "Rejected",         val: totalRejected,   color: "#f87171",  bg: "rgba(248,113,113,0.08)", bdr: "rgba(248,113,113,0.18)" },
    { label: "Pending Review",   val: totalPending,    color: "#fbbf24",  bg: "rgba(251,191,36,0.08)",  bdr: "rgba(251,191,36,0.18)"  },
    { label: "Acceptance Rate",  val: `${acceptRate}%`,color: "#a78bfa",  bg: "rgba(167,139,250,0.08)", bdr: "rgba(167,139,250,0.18)" },
  ];

  const toggle = (type) => setActiveTable(prev => prev === type ? null : type);

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div className={styles.modal} onClick={e => e.stopPropagation()}>

        {/* HEADER */}
        <div className={styles.modalHeader}>
          <div>
            <h2 className={styles.modalTitle}>Hiring Statistics</h2>
            <p className={styles.modalSub}>Live pipeline analytics across all your job postings</p>
          </div>
          <button className={styles.closeBtn} onClick={onClose}>✕</button>
        </div>

        {/* NUMBER STATS */}
        <div className={styles.overviewGrid}>
          {overviewItems.map(({ label, val, color, bg, bdr }) => (
            <div key={label} className={styles.overviewCard} style={{ background: bg, borderColor: bdr }}>
              <span className={styles.overviewVal} style={{ color }}>{val}</span>
              <span className={styles.overviewLabel}>{label}</span>
            </div>
          ))}
        </div>

        {/* FUNNEL */}
        <div className={styles.funnelSection}>
          <p className={styles.sectionTitle}>
            <span className={styles.sectionDash}>—</span>
            Hiring Funnel
            <span className={styles.sectionDash}>—</span>
          </p>
          <Funnel
            total={totalApplicants}
            accepted={totalAccepted}
            rejected={totalRejected}
            pending={totalPending}
          />
        </div>

        {/* TOGGLE BUTTONS */}
        <div className={styles.tableToggles}>
          <button
            className={`${styles.toggleBtn} ${activeTable === "Accepted" ? styles.toggleTeal : ""}`}
            onClick={() => toggle("Accepted")}
          >
            <span className={styles.toggleDot} style={{ background: "#00d4aa" }} />
            Accepted Candidates
            <span className={`${styles.toggleBadge} ${styles.badgeTeal}`}>{totalAccepted}</span>
            <span className={styles.toggleCaret}>{activeTable === "Accepted" ? "▲" : "▼"}</span>
          </button>

          <button
            className={`${styles.toggleBtn} ${activeTable === "Rejected" ? styles.toggleRed : ""}`}
            onClick={() => toggle("Rejected")}
          >
            <span className={styles.toggleDot} style={{ background: "#f87171" }} />
            Rejected Candidates
            <span className={`${styles.toggleBadge} ${styles.badgeRed}`}>{totalRejected}</span>
            <span className={styles.toggleCaret}>{activeTable === "Rejected" ? "▲" : "▼"}</span>
          </button>
        </div>

        {/* ACCEPTED TABLE */}
        {activeTable === "Accepted" && (
          <div className={styles.tableSection}>
            <CandidateTable candidates={decided.accepted} type="Accepted" />
          </div>
        )}

        {/* REJECTED TABLE */}
        {activeTable === "Rejected" && (
          <div className={styles.tableSection}>
            <CandidateTable candidates={decided.rejected} type="Rejected" />
          </div>
        )}

      </div>
    </div>
  );
};